package com.lge.adder;

import android.test.ActivityInstrumentationTestCase2;
import android.widget.EditText;
import android.widget.Button;
import android.test.UiThreadTest;

/**
 * This is a simple framework for a test of an Application.  See
 * {@link android.test.ApplicationTestCase ApplicationTestCase} for more information on
 * how to write and extend Application tests.
 * <p/>
 * To run this test, you can type:
 * adb shell am instrument -w \
 * -e class com.lge.adder.MainActivityTest \
 * com.lge.adder.tests/android.test.InstrumentationTestRunner
 */
public class MainActivityTest extends ActivityInstrumentationTestCase2<MainActivity> {

    public MainActivityTest() {
        super("com.lge.adder", MainActivity.class);
    }

	@UiThreadTest
	public void testAddButton() {
		MainActivity activity = getActivity();
		
		EditText inputA = (EditText) activity.findViewById(R.id.input_a);
		EditText inputB = (EditText) activity.findViewById(R.id.input_b);
		Button   addBtn = (Button)   activity.findViewById(R.id.button_add);
		EditText result = (EditText) activity.findViewById(R.id.result);

		inputA.setText("10");
		inputB.setText("15");
		addBtn.performClick();
		
		assertEquals("25", result.getText().toString());
	}
	
	public void testAddFunc() {
		MainActivity activity = getActivity();
		assertEquals(100, activity.plusFunc(45, 55));		
	}

}

/** Automatically generated file. DO NOT MODIFY */
package com.lge.adder.tests;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
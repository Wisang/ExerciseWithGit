package com.lge.adder;

import android.app.Activity;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Button;


public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		final EditText inputA = (EditText) findViewById(R.id.input_a);
		final EditText inputB = (EditText) findViewById(R.id.input_b);
		Button   addBtn = (Button)   findViewById(R.id.button_add);
		final EditText result = (EditText) findViewById(R.id.result);

		// interface OnClickListener {
		//	public void onClick(View v);
		// }

		addBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int a = Integer.valueOf(inputA.getText().toString());
				int b = Integer.valueOf(inputB.getText().toString());
				int c = plusFunc(a , b);
				result.setText(String.valueOf(c));
			}
		});
    }
    
    public int plusFunc(int a, int b) {
    	return a + b;
    }

    public int subFunc(int a, int b) {
    	return a - b;
    }

}

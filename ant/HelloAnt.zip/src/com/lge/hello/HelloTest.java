package com.lge.hello;

import junit.framework.*;

public class HelloTest extends TestCase {

    public void testFirst() {
    	assertEquals(1, 1);
        fail("This is Hello Test Failure Message");
    }
	
}